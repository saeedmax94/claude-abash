import { Routes, Route, Navigate, NavLink, Outlet } from 'react-router-dom';
import { useAuth } from './auth.jsx';
import Login from './pages/Login.jsx';
import Forgot from './pages/Forgot.jsx';
import Reset from './pages/Reset.jsx';
import Articles from './pages/Articles.jsx';
import Songs from './pages/Songs.jsx';
import Languages from './pages/Languages.jsx';
import Dictionary from './pages/Dictionary.jsx';
import Membership from './pages/Membership.jsx';

const links = [
  ['/', 'الأخبار'],
  ['/history', 'التاريخ النوبي'],
  ['/pyramids', 'الأهرامات'],
  ['/songs', 'الأغاني'],
  ['/languages', 'اللغات'],
  ['/dictionary', 'القاموس'],
  ['/membership', 'العضوية'],
];

function Layout() {
  const { user, logout } = useAuth();
  return (
    <>
      <header className="top">
        <strong className="brand">النوبة</strong>
        <nav>
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === '/'}>
              {label}
            </NavLink>
          ))}
        </nav>
        <span className="who">
          {user.name}
          <button className="link" onClick={logout}>
            خروج
          </button>
        </span>
      </header>
      <div className="band" />
      <main className="page">
        <Outlet />
      </main>
    </>
  );
}

function Protected() {
  const { user, ready } = useAuth();
  if (!ready) return <p className="center">جارٍ التحميل…</p>;
  return user ? <Layout /> : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/forgot-password" element={<Forgot />} />
      <Route path="/reset-password" element={<Reset />} />
      <Route element={<Protected />}>
        <Route index element={<Articles section="news" title="الأخبار" />} />
        <Route path="history" element={<Articles section="history" title="التاريخ النوبي" />} />
        <Route path="pyramids" element={<Articles section="pyramids" title="الأهرامات" />} />
        <Route path="songs" element={<Songs />} />
        <Route path="languages" element={<Languages />} />
        <Route path="dictionary" element={<Dictionary />} />
        <Route path="membership" element={<Membership />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
