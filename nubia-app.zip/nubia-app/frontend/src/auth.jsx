import { createContext, useContext, useEffect, useState } from 'react';
import { api, getToken, setToken } from './api.js';

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(!getToken());

  useEffect(() => {
    if (getToken()) {
      api('/me')
        .then(setUser)
        .catch(() => setToken(null))
        .finally(() => setReady(true));
    }
    const lost = () => setUser(null);
    window.addEventListener('auth:lost', lost);
    return () => window.removeEventListener('auth:lost', lost);
  }, []);

  const login = async (username, password) => {
    const d = await api('/login', { method: 'POST', body: { username, password } });
    setToken(d.token);
    setUser(d.user);
  };

  const logout = async () => {
    try {
      await api('/logout', { method: 'POST' });
    } catch {
      /* token already invalid */
    }
    setToken(null);
    setUser(null);
  };

  return <Ctx.Provider value={{ user, ready, login, logout }}>{children}</Ctx.Provider>;
}
