import { useCallback, useEffect, useState } from 'react';
import { api, useFetch } from '../api.js';
import { useAuth } from '../auth.jsx';

const empty = { arabic: '', nubian: '', language_id: '', transliteration: '' };

export default function Dictionary() {
  const { user } = useAuth();
  const { data: langs } = useFetch('/languages');
  const [q, setQ] = useState('');
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(empty);
  const [error, setError] = useState('');

  const load = useCallback(
    () =>
      api('/words?q=' + encodeURIComponent(q))
        .then((r) => setRows(r.data))
        .catch((e) => setError(e.message)),
    [q]
  );

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
  }, [load]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const add = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await api('/words', {
        method: 'POST',
        body: { ...form, language_id: Number(form.language_id) || null },
      });
      setForm({ ...empty, language_id: form.language_id });
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  const remove = async (id) => {
    if (!window.confirm('حذف هذه الكلمة؟')) return;
    try {
      await api('/words/' + id, { method: 'DELETE' });
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <>
      <h2>القاموس: عربي ← نوبي</h2>

      <form className="row" onSubmit={add}>
        <label>
          الكلمة بالعربية
          <input value={form.arabic} onChange={set('arabic')} required />
        </label>
        <label>
          ما يقابلها بالنوبية
          <input value={form.nubian} onChange={set('nubian')} required />
        </label>
        <label>
          اللغة
          <select value={form.language_id} onChange={set('language_id')} required>
            <option value="">اختر</option>
            {langs?.map((l) => (
              <option key={l.id} value={l.id}>{l.name_ar}</option>
            ))}
          </select>
        </label>
        <label>
          النطق بحروف عربية (اختياري)
          <input value={form.transliteration} onChange={set('transliteration')} />
        </label>
        <button className="primary">إضافة</button>
      </form>

      {error && <p className="error" role="alert">{error}</p>}

      <input className="search" type="search" placeholder="ابحث في القاموس" value={q} onChange={(e) => setQ(e.target.value)} />

      <table>
        <thead>
          <tr><th>عربي</th><th>نوبي</th><th>اللغة</th><th>النطق</th><th /></tr>
        </thead>
        <tbody>
          {rows.map((w) => (
            <tr key={w.id}>
              <td>{w.arabic}</td>
              <td>{w.nubian}</td>
              <td>{w.language?.name_ar}</td>
              <td>{w.transliteration}</td>
              <td>
                {w.user_id === user.id && (
                  <button className="link" onClick={() => remove(w.id)}>حذف</button>
                )}
              </td>
            </tr>
          ))}
          {rows.length === 0 && (
            <tr><td colSpan="5">لا توجد كلمات مطابقة.</td></tr>
          )}
        </tbody>
      </table>
    </>
  );
}
