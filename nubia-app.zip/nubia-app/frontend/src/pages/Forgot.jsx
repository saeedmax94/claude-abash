import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';

export default function Forgot() {
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setMsg('');
    setBusy(true);
    try {
      const d = await api('/forgot-password', { method: 'POST', body: { email: email.trim() } });
      setMsg(d.message);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth">
      <div className="band" />
      <form className="card" onSubmit={submit}>
        <h1>تغيير كلمة السر</h1>
        <p>اكتب بريدك الإلكتروني وسنرسل إليه رابطاً لتعيين كلمة سر جديدة.</p>
        <label>
          البريد الإلكتروني
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required autoFocus />
        </label>
        {error && <p className="error" role="alert">{error}</p>}
        {msg && <p className="ok" role="status">{msg}</p>}
        <button className="primary" disabled={busy}>{busy ? 'جارٍ الإرسال…' : 'إرسال الرابط'}</button>
        <Link to="/login">العودة لتسجيل الدخول</Link>
      </form>
    </div>
  );
}
