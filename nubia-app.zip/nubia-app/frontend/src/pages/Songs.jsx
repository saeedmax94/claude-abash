import { useFetch } from '../api.js';

export default function Songs() {
  const { data, error } = useFetch('/songs');
  return (
    <>
      <h2>الأغاني النوبية</h2>
      {error && <p className="error">{error}</p>}
      {!data && !error && <p>جارٍ التحميل…</p>}
      {data?.length === 0 && <p>لم تُضف أغانٍ بعد.</p>}
      {data?.map((s) => (
        <article key={s.id} className="item">
          <h3>{s.title}</h3>
          <p className="meta">{[s.artist, s.language].filter(Boolean).join(' – ')}</p>
          {s.description && <p className="text">{s.description}</p>}
          {s.url && (
            <a href={s.url} target="_blank" rel="noopener noreferrer">
              استمع
            </a>
          )}
        </article>
      ))}
    </>
  );
}
