import { useFetch } from '../api.js';

export default function Articles({ section, title }) {
  const { data, error } = useFetch(`/articles/${section}`);
  return (
    <>
      <h2>{title}</h2>
      {error && <p className="error">{error}</p>}
      {!data && !error && <p>جارٍ التحميل…</p>}
      {data?.length === 0 && <p>لا يوجد محتوى بعد.</p>}
      {data?.map((a) => (
        <article key={a.id} className="item">
          <h3>{a.title}</h3>
          <p className="text">{a.body}</p>
        </article>
      ))}
    </>
  );
}
