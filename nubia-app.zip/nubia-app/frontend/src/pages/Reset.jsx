import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { api } from '../api.js';

export default function Reset() {
  const [params] = useSearchParams();
  const token = params.get('token') || '';
  const email = params.get('email') || '';
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (password !== confirm) return setError('كلمتا السر غير متطابقتين.');
    setBusy(true);
    try {
      const d = await api('/reset-password', {
        method: 'POST',
        body: { token, email, password, password_confirmation: confirm },
      });
      setMsg(d.message);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth">
      <div className="band" />
      <form className="card" onSubmit={submit}>
        <h1>كلمة سر جديدة</h1>
        {!token || !email ? (
          <p className="error">الرابط غير مكتمل. اطلب رابطاً جديداً.</p>
        ) : msg ? (
          <p className="ok" role="status">{msg}</p>
        ) : (
          <>
            <label>
              كلمة السر الجديدة (8 أحرف على الأقل)
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" minLength={8} required autoFocus />
            </label>
            <label>
              أعد كتابة كلمة السر
              <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" minLength={8} required />
            </label>
            {error && <p className="error" role="alert">{error}</p>}
            <button className="primary" disabled={busy}>{busy ? 'جارٍ الحفظ…' : 'حفظ كلمة السر'}</button>
          </>
        )}
        <Link to={msg ? '/login' : '/forgot-password'}>{msg ? 'تسجيل الدخول' : 'طلب رابط جديد'}</Link>
      </form>
    </div>
  );
}
