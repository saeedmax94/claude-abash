import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';

export default function Membership() {
  const { user } = useAuth();
  const [form, setForm] = useState({ full_name: user.name, phone: '', city: '', notes: '' });
  const [saved, setSaved] = useState(false);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    api('/membership')
      .then((m) => {
        if (m) {
          setSaved(true);
          setForm({
            full_name: m.full_name,
            phone: m.phone || '',
            city: m.city || '',
            notes: m.notes || '',
          });
        }
      })
      .catch((e) => setError(e.message));
  }, []);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setMsg('');
    try {
      await api('/membership', { method: 'POST', body: form });
      setSaved(true);
      setMsg('تم حفظ بيانات العضوية.');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <>
      <h2>تسجيل العضوية</h2>
      {saved && <p className="ok">أنت مسجّل عضواً. يمكنك تعديل بياناتك أدناه.</p>}
      <form className="card flat" onSubmit={submit}>
        <label>
          الاسم الكامل
          <input value={form.full_name} onChange={set('full_name')} required />
        </label>
        <label>
          رقم الهاتف
          <input value={form.phone} onChange={set('phone')} inputMode="tel" />
        </label>
        <label>
          المدينة
          <input value={form.city} onChange={set('city')} />
        </label>
        <label>
          ملاحظات
          <textarea rows="3" value={form.notes} onChange={set('notes')} />
        </label>
        {error && <p className="error" role="alert">{error}</p>}
        {msg && <p className="ok" role="status">{msg}</p>}
        <button className="primary">{saved ? 'حفظ التعديلات' : 'تسجيل العضوية'}</button>
      </form>
    </>
  );
}
