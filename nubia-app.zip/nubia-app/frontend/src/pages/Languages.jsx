import { useFetch } from '../api.js';

export default function Languages() {
  const { data, error } = useFetch('/languages');
  return (
    <>
      <h2>لغات النوبة</h2>
      {error && <p className="error">{error}</p>}
      {!data && !error && <p>جارٍ التحميل…</p>}
      {data?.map((l) => (
        <article key={l.id} className="item">
          <h3>{l.name_ar}</h3>
          <p className="meta">{[l.name_en, l.region].filter(Boolean).join(' – ')}</p>
          {l.description && <p className="text">{l.description}</p>}
        </article>
      ))}
    </>
  );
}
