import { useEffect, useState } from 'react';

const BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

export const getToken = () => localStorage.getItem('token');
export const setToken = (t) =>
  t ? localStorage.setItem('token', t) : localStorage.removeItem('token');

export async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      ...(getToken() ? { Authorization: `Bearer ${getToken()}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = res.status === 204 ? null : await res.json().catch(() => null);

  if (!res.ok) {
    if (res.status === 401) {
      setToken(null);
      window.dispatchEvent(new Event('auth:lost'));
    }
    const first = data?.errors ? Object.values(data.errors)[0][0] : null;
    throw new Error(first || data?.message || 'حدث خطأ. حاول مرة أخرى.');
  }
  return data;
}

// Loads a GET endpoint once per path.
export function useFetch(path) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => {
    let live = true;
    setData(null);
    setError('');
    api(path)
      .then((d) => live && setData(d))
      .catch((e) => live && setError(e.message));
    return () => {
      live = false;
    };
  }, [path]);
  return { data, error };
}
