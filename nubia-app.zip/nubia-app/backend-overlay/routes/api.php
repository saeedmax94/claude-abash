<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\ContentController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\WordController;
use Illuminate\Support\Facades\Route;

Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1');
Route::post('/forgot-password', [AuthController::class, 'forgot'])->middleware('throttle:5,1');
Route::post('/reset-password', [AuthController::class, 'reset'])->middleware('throttle:10,1');

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);

    Route::get('/articles/{section}', [ContentController::class, 'articles']);
    Route::get('/songs', [ContentController::class, 'songs']);
    Route::get('/languages', [ContentController::class, 'languages']);

    Route::get('/words', [WordController::class, 'index']);
    Route::post('/words', [WordController::class, 'store']);
    Route::delete('/words/{word}', [WordController::class, 'destroy']);

    Route::get('/membership', [MemberController::class, 'show']);
    Route::post('/membership', [MemberController::class, 'store']);
});
