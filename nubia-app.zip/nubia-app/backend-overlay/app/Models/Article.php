<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    protected $fillable = ['section', 'title', 'body', 'published_at'];
    protected $casts = ['published_at' => 'datetime'];
}
