<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Word extends Model
{
    protected $fillable = ['arabic', 'nubian', 'language_id', 'transliteration', 'user_id'];

    public function language()
    {
        return $this->belongsTo(NubianLanguage::class, 'language_id');
    }
}
