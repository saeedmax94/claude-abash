<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NubianLanguage extends Model
{
    protected $table = 'languages';
    protected $fillable = ['name_ar', 'name_en', 'region', 'description'];
}
