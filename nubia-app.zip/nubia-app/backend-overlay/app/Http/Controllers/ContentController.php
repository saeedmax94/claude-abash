<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Models\NubianLanguage;
use App\Models\Song;

class ContentController extends Controller
{
    public function articles(string $section)
    {
        abort_unless(in_array($section, ['news', 'history', 'pyramids'], true), 404);

        return Article::where('section', $section)
            ->orderByDesc('published_at')
            ->orderBy('id')
            ->get();
    }

    public function songs()
    {
        return Song::orderBy('title')->get();
    }

    public function languages()
    {
        return NubianLanguage::orderBy('name_ar')->get();
    }
}
