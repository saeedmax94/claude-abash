<?php

namespace App\Http\Controllers;

use App\Models\Word;
use Illuminate\Http\Request;

class WordController extends Controller
{
    public function index(Request $r)
    {
        $query = Word::with('language:id,name_ar')->latest('id');

        $s = trim((string) $r->query('q', ''));
        if ($s !== '') {
            $like = '%' . addcslashes($s, '%_\\') . '%';
            $query->where(fn ($w) => $w
                ->where('arabic', 'like', $like)
                ->orWhere('nubian', 'like', $like)
                ->orWhere('transliteration', 'like', $like));
        }

        return $query->paginate(50);
    }

    public function store(Request $r)
    {
        $data = $r->validate([
            'arabic' => 'required|string|max:100',
            'nubian' => 'required|string|max:100',
            'language_id' => 'required|integer|exists:languages,id',
            'transliteration' => 'nullable|string|max:100',
        ]);

        $word = $r->user()->words()->create($data);

        return response()->json($word->load('language:id,name_ar'), 201);
    }

    public function destroy(Request $r, Word $word)
    {
        abort_unless($word->user_id === $r->user()->id, 403);
        $word->delete();

        return response()->noContent();
    }
}
