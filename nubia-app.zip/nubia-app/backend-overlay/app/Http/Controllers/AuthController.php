<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function login(Request $r)
    {
        $data = $r->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        $user = User::where('username', $data['username'])->first();

        if (!$user || !Hash::check($data['password'], $user->password)) {
            throw ValidationException::withMessages([
                'username' => 'اسم المستخدم أو كلمة السر غير صحيحة.',
            ]);
        }

        return [
            'token' => $user->createToken('web')->plainTextToken,
            'user' => $user->only(['id', 'name', 'username', 'email']),
        ];
    }

    public function logout(Request $r)
    {
        $r->user()->currentAccessToken()->delete();
        return ['message' => 'تم تسجيل الخروج.'];
    }

    public function me(Request $r)
    {
        return $r->user()->only(['id', 'name', 'username', 'email']);
    }

    public function forgot(Request $r)
    {
        $r->validate(['email' => 'required|email']);

        // The answer is the same whether or not the email exists,
        // so nobody can use this form to find out who has an account.
        Password::sendResetLink($r->only('email'));

        return ['message' => 'إذا كان البريد مسجلاً لدينا فقد أرسلنا إليه رابط تغيير كلمة السر.'];
    }

    public function reset(Request $r)
    {
        $r->validate([
            'token' => 'required|string',
            'email' => 'required|email',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $status = Password::reset(
            $r->only('email', 'password', 'password_confirmation', 'token'),
            function (User $user, string $password) {
                $user->forceFill(['password' => $password])->save(); // hashed by the model cast
                $user->tokens()->delete(); // sign out every device
            }
        );

        if ($status !== Password::PASSWORD_RESET) {
            throw ValidationException::withMessages([
                'email' => 'الرابط غير صالح أو انتهت صلاحيته. اطلب رابطاً جديداً.',
            ]);
        }

        return ['message' => 'تم تغيير كلمة السر. يمكنك تسجيل الدخول الآن.'];
    }
}
