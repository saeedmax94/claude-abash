<?php

namespace App\Http\Controllers;

use App\Models\Member;
use Illuminate\Http\Request;

class MemberController extends Controller
{
    public function show(Request $r)
    {
        return response()->json($r->user()->member);
    }

    public function store(Request $r)
    {
        $data = $r->validate([
            'full_name' => 'required|string|max:150',
            'phone' => 'nullable|string|max:30',
            'city' => 'nullable|string|max:100',
            'notes' => 'nullable|string|max:1000',
        ]);

        $member = Member::updateOrCreate(['user_id' => $r->user()->id], $data);

        return response()->json($member);
    }
}
