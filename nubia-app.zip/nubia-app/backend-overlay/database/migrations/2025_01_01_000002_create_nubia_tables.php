<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // news | history | pyramids
        Schema::create('articles', function (Blueprint $t) {
            $t->id();
            $t->string('section', 20)->index();
            $t->string('title');
            $t->text('body');
            $t->timestamp('published_at')->nullable();
            $t->timestamps();
        });

        Schema::create('songs', function (Blueprint $t) {
            $t->id();
            $t->string('title');
            $t->string('artist')->nullable();
            $t->string('language')->nullable();
            $t->string('url')->nullable();
            $t->text('description')->nullable();
            $t->timestamps();
        });

        Schema::create('languages', function (Blueprint $t) {
            $t->id();
            $t->string('name_ar');
            $t->string('name_en')->nullable();
            $t->string('region')->nullable();
            $t->text('description')->nullable();
            $t->timestamps();
        });

        Schema::create('words', function (Blueprint $t) {
            $t->id();
            $t->string('arabic', 100)->index();
            $t->string('nubian', 100);
            $t->foreignId('language_id')->constrained('languages')->cascadeOnDelete();
            $t->string('transliteration', 100)->nullable();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->timestamps();
        });

        Schema::create('members', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->unique()->constrained()->cascadeOnDelete();
            $t->string('full_name');
            $t->string('phone', 30)->nullable();
            $t->string('city', 100)->nullable();
            $t->text('notes')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('members');
        Schema::dropIfExists('words');
        Schema::dropIfExists('languages');
        Schema::dropIfExists('songs');
        Schema::dropIfExists('articles');
    }
};
