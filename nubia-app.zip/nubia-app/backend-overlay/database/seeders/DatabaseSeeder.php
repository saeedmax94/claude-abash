<?php

namespace Database\Seeders;

use App\Models\Article;
use App\Models\NubianLanguage;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // First account. Change the password after the first login.
        User::firstOrCreate(
            ['username' => 'admin'],
            ['name' => 'المدير', 'email' => 'admin@example.com', 'password' => 'ChangeMe-123']
        );

        foreach ([
            ['name_ar' => 'النوبيين (نوبين)', 'name_en' => 'Nobiin', 'region' => 'شمال السودان'],
            ['name_ar' => 'الدنقلاوية', 'name_en' => 'Dongolawi (Andaandi)', 'region' => 'دنقلا وما حولها'],
            ['name_ar' => 'الكنزية', 'name_en' => 'Kenzi', 'region' => 'شمال السودان'],
            ['name_ar' => 'الميدوبية', 'name_en' => 'Midob', 'region' => 'دارفور'],
            ['name_ar' => 'البرقد', 'name_en' => 'Birgid', 'region' => 'دارفور'],
        ] as $lang) {
            NubianLanguage::firstOrCreate(['name_en' => $lang['name_en']], $lang);
        }

        $articles = [
            ['news', 'أهلاً بكم', 'بدأ العمل على هذا الموقع. تابعوا هنا الأخبار والإضافات الجديدة.'],
            ['history', 'كرمة وكوش', "ازدهرت مملكة كرمة في أعالي النيل منذ نحو 2500 ق.م، ثم قامت مملكة كوش بعاصمتيها نبتة ومروي.\nاستبدل هذا النص بنص تاريخي موثّق."],
            ['pyramids', 'أهرامات مروي', 'بنى ملوك كوش وملكاتها مئات الأهرامات في مروي والكرو ونوري. استبدل هذا النص بنص موثّق وأضف الصور لاحقاً.'],
        ];
        foreach ($articles as [$section, $title, $body]) {
            Article::firstOrCreate(
                ['section' => $section, 'title' => $title],
                ['body' => $body, 'published_at' => now()]
            );
        }
    }
}
