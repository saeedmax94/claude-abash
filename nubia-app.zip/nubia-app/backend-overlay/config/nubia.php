<?php

return [
    // Address of the React app. Used inside the password-reset email link.
    'frontend_url' => env('FRONTEND_URL', 'http://localhost:5173'),
];
